=== verse ===
Contributors: v3rse0ne
Plugin Name: verse
Plugin URI: https://github.com/v3rse0ne/verse
Description: Custom utility plugin
Version: 1.0.0
Author: v3rse0ne
License: GPLv2
